from django.apps import AppConfig


class MyclassConfig(AppConfig):
    name = 'myclass'
